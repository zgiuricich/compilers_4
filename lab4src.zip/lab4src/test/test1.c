int x;
int a[10];

int f(void) { return 3; }

void main(void) { }

void g(void) {}

