void f(void) {
  int x;
  int y[10];
}

int g(int x) {
  z = 20 + w;z
}

