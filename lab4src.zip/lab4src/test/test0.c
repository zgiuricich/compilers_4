int x;
int a[10];
void main(void){}
void main(void){}
