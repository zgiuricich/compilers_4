int x;
int y[10];

int f(int x) {
  y = x[2] ;
}
