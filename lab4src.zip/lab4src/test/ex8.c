void f(int x) {
  int a;
  a = x;
  int b;
}
