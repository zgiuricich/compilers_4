int x;
void f(int x){}
int y[10];
