/*
 * Test some parsing
 * There may be one line in here that shouldn't produce an error.
 */

int main(void){
  int cello;
  int hello;

  int x = 12;

  x = 15 - x;

  x = hello - int;

  print( int x);

}
