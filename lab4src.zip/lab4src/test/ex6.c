void f(int x);
