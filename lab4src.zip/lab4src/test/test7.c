void f(void) {
  int x;
  int y[10];
}

int g(int x) {
  f = 20;
}

