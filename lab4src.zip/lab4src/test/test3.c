int x;
int x[10];
