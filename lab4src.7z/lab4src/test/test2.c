int x;
int a[10];

int f(void) { }

void g(int x, int y, int z[]) {}

void main(int x) {int y;}

