void f(int x) {
  int a = 20;
}
