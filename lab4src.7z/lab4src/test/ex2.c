int x;
void f(){}
