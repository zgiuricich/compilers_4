int x;
int a[10];

int f(void) {}

void main(int x) {int y;}

void g(int x, int y, int z[]) {}



